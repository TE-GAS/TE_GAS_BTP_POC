const cds = require('@sap/cds');

module.exports = cds.service.impl(async function () {
    const [ DS4reportServ,DG1FIreportServ ] = await Promise.all( [ cds.connect.to('DS4') ,cds.connect.to('DG1'), ] );
    this.on ("READ", "ReportDataDS4", async (req) => {
        const tx = DS4reportServ.tx(req);
        const result = await tx.run(req.query);
        return result.slice(2);
    });

    this.on ("READ", "ReportDataDG1", async (req) => {
        const tx = DG1FIreportServ.tx(req);
        const result = await tx.run(req.query);
        return result.slice(2);
      
    });

    this.on ("READ", "ReportColumnDS4", async (req) => {
        const tx = DS4reportServ.tx(req);
        const result = await tx.run(req.query);
        return result.slice(0,2);
    });

    this.on ("READ",  "TcodeValueHelp", async (req) => {
        const tx = DS4reportServ.tx(req);
        const result = await tx.run(req.query);
        return result;
      
    });

    this.on ("READ",  "VariantValueHelp", async (req) => {
        const tx = DS4reportServ.tx(req);
        const result = await tx.run(req.query);
        return result;
    });

});