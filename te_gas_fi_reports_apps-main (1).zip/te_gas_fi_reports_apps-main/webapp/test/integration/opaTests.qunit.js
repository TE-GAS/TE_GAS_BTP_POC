/* global QUnit */

sap.ui.require(["te/gas/fi/report/comtefireport/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
