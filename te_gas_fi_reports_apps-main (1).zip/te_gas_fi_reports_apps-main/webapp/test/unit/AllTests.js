sap.ui.define([
	"te/gas/fi/report/comtefireport/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
