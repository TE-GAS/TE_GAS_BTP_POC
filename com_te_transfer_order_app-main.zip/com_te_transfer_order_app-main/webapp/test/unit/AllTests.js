sap.ui.define([
	"com.te.transfer.order/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
