/* global QUnit */

sap.ui.require(["com/te/transfer/order/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
