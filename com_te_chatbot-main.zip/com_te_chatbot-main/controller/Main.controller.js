sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/json/JSONModel"], function (e, t) {
    "use strict";
    return e.extend("comteaichatbot.controller.Main", {
        onInit: function () {
            const e = new t();
            e.setData({ conversationId: "", messageId: "", message_time: "", user_id: "", user_query: "", chatHistory: [], isBusy: false, enableTextArea: true });
            this.getView().setModel(e, "chatModel");
        },

        onSendMessage: function (e) {
            this.setBusy(true);
            const t = e.getParameter("value");
            this.setUserQuestionInToChatMessage(t);
            const s = this.getView().getModel("chatModel");
            const o = s.getProperty("/conversationId");
            const a = JSON.stringify({ conversationId: o, messageId: s.getProperty("/messageId"), message_time: s.getProperty("/message_time"), user_id: s.getProperty("/user_id"), user_query: s.getProperty("/user_query") });
            this.sendMessage(t)
                .then((e) => {
                    this.setBackendResponseInToChatMessage(e);
                })
                .catch((e) => {
                    console.log(e);
                })
                .finally(() => {
                    this.setBusy(false);
                    this.setEnableTextArea(true);
                });
        },
        setBusy: function (e) {
            const t = "/isBusy";
            this.getView().getModel("chatModel").setProperty(t, e);
        },
        setEnableTextArea: function (e) {
            const t = "/enableTextArea";
            this.getView().getModel("chatModel").setProperty(t, e);
        },
        setUserQuestionInToChatMessage(e) {
            const t = this.getView().getModel("chatModel");
            const s = "/chatHistory";
            const o = t.getProperty(s);
            t.setProperty("/messageId", self.crypto.randomUUID());
            t.setProperty("/message_time", new Date().toISOString());
            t.setProperty("/user_query", e);
            const a = { messageId: t.getProperty("/messageId"), message_time: new Date(t.getProperty("/message_time")), content: e, user_role: "You", icon_path: "" };
            o.push(a);
            t.setProperty(s, o);
        },
        sendMessage: function (e) {
            var t = JSON.stringify({ prompt: e });
            return new Promise((e, s) => {
                $.ajax({
                    url: "https://demoaiagent-industrious-platypus-pt.cfapps.us10-001.hana.ondemand.com/AIAgent/CallAgent",
                    type: "POST",
                    contentType: "application/json",
                    async: true,
                    data: t,
                    success: function (t, o, a) {
                        console.log(a);
                        if (a.status === 200 || a.status === 201) {
                            var a = JSON.parse(a.responseText);
                            if (a.length > 1) {
                                a = a[a.length - 1];
                            }
                            e(a);
                        } else {
                            s(a.responseText);
                        }
                    },
                    error: function (e, t) {
                        if (e) {
                            if (e.responseText) {
                                s("Error");
                            } else {
                                s(e.responseText);
                            }
                        } else {
                            s(t);
                        }
                    },
                });
            });
        },
        setBackendResponseInToChatMessage(e) {
            const t = this.getView().getModel("chatModel");
            const s = { messageId: self.crypto.randomUUID(), message_time: new Date(), content: e, user_id: "", user_role: "AI", icon_path: "sap-icon://da-2", initials: "" };
            const o = "/chatHistory";
            const a = t.getProperty(o);
            a.push(s);
            t.setProperty(o, a);
        },
        AfterUpdating: function () {
            var e = this.getView().byId("officialRightScreenVBoxList");
            var t = this.getView().byId("initialRightScreen");
            var s = e.getItems();
            if (s.length > 0) {
                var o = document.getElementById(s[s.length - 1].sId);
                t.scrollToElement(o, 4, [0, 0]);
            }
        },
    });
});
//# sourceMappingURL=Main.controller.js.map
