sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/m/HBox",
        "sap/m/Text",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/BusyIndicator",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/m/MessageBox",
        "sap/ui/export/library",
        "sap/ui/export/Spreadsheet"
    ],
    function (Controller, HBox, Text, JSONModel, BusyIndicator, Filter, FilterOperator, MessageBox, ExportLibrary, Spreadsheet) {
        "use strict";

        const EdmType = ExportLibrary.EdmType;


        return Controller.extend("transferorderapp.controller.Details", {
            onInit: function () {

                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("Details").attachPatternMatched(this._onObjectMatchedForDetails, this);
                //console.log("ReachedHere");


            },
            _onObjectMatchedForDetails: async function (oEvent) {
                var ID = oEvent.getParameter("arguments").ID;
                let oRouteDetailsModel = this.getOwnerComponent().getModel("routeModel");
                
                if(oRouteDetailsModel == undefined){
                    const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    BusyIndicator.hide()
                    oRouter.navTo("RouteMain")
                }
                this.oSelectedObject = oRouteDetailsModel.getData();
                let oHeaderModel = new JSONModel();
                this.getView().setModel(oHeaderModel, "oHeaderModel");
                oHeaderModel.setData(this.oSelectedObject)
                let oView = this.getView();
                let aOrderItem = [];
                // To Fetch Order Header
                aOrderItem = await this._fetchOrderItem(this.oSelectedObject)
                    .catch(function (oError) {
                        oView.setBusy(false);
                        MessageBox.error(`Unable to retrieve the Data. Please try again.`)
                    });
                let oItemModel = new JSONModel();
                this.getView().setModel(oItemModel, "oItemModel");
                oItemModel.setData(aOrderItem)
            },
            _fetchOrderItem: function (HeaderData) {
                var that = this;
                let oDataModel = this.getOwnerComponent().getModel("mainServiceV2");
                var url = "/OrderHeader(ID=guid'"+HeaderData.ID+"',LGNUM='"+HeaderData.LGNUM+"',TANUM="+HeaderData.TANUM+")/to_OrderItem";
                return new Promise(function (resolve, reject) {
                    oDataModel.read(url, {
                        success: function (response) {
                            resolve(response['results'][0]);
                        },
                        error: function (oError) {
                            reject(oError);
                        },
                    });
                });
    
            },

        });
    }
);
