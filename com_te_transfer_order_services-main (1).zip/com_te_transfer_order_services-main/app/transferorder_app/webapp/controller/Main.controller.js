sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/BusyDialog",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
],
    function (
        Controller,
        Fragment,
        JSONModel,
        MessageToast,
        BusyDialog,
        Filter,
        FilterOperator,
        MessageBox
    ) {
    "use strict";

    return Controller.extend("transferorderapp.controller.Main", {
        onInit:async function() {
            let oOrderHeaderModel = new JSONModel();
                this.getView().setModel(oOrderHeaderModel, "oOrderHeaderModel");
            let oRouteModel = new JSONModel();
                this.getOwnerComponent().setModel(oRouteModel,"routeModel");
            let oView = this.getView();
            let aOrderDetails = [];
            // To Fetch Order Header
            aOrderDetails = await this._fetchOrderHeader()
                .catch(function (oError) {
                    oView.setBusy(false);
                    MessageBox.error(`Unable to retrieve the Data. Please try again.`)
                });
            aOrderDetails = aOrderDetails.results;
            oOrderHeaderModel.setData(aOrderDetails);
            oOrderHeaderModel.refresh(true);
            this.getOwnerComponent().setModel(oOrderHeaderModel,"oOrderHeaderModel")
        },
        _fetchOrderHeader: function () {
            var that = this;
            let oDataModel = this.getOwnerComponent().getModel("mainServiceV2");
            return new Promise(function (resolve, reject) {
                oDataModel.read("/OrderHeader", {
                    success: function (response) {
                        resolve(response);
                    },
                    error: function (oError) {
                        reject(oError);
                    },
                });
            });

        },
        onPressRow: function (oEvent) {
            let oRouteDetailsModel =
                    this.getOwnerComponent().getModel("routeModel");
            const oSelectedItem = oEvent.getSource(); // Get the selected item (row)
            const oContext = oSelectedItem.getBindingContext("oOrderHeaderModel"); // Get the binding context of the selected item
            this.oSelectedObject = oContext.getObject(); // Get the object bound to the selected item
            oRouteDetailsModel.setData(this.oSelectedObject);
            const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            oRouter.navTo("Details", {
                ID:this.oSelectedObject.ID
            });

        }
    });
});