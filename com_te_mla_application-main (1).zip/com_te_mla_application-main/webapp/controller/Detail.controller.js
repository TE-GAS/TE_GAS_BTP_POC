sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/HBox",
    "sap/m/Text",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/BusyIndicator",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
    "sap/ui/export/library",
    "sap/ui/export/Spreadsheet",
    "sap/ui/core/Fragment"
], (Controller, HBox, Text, JSONModel, BusyIndicator, Filter, FilterOperator, MessageBox, ExportLibrary, Spreadsheet,Fragment) => {
    "use strict";

    return Controller.extend("comtemlaapplication.controller.Detail", {
        onInit() {
            var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("TargetDetail").attachPatternMatched(this._onObjectMatchedForDetails, this);
                //console.log("ReachedHere");
        },
            _onObjectMatchedForDetails: async function (oEvent) {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                let oSelectedInventoryModel = new JSONModel();
                this.getOwnerComponent().setModel(oSelectedInventoryModel, "oSelectedInventoryModel");
                var rackid = oEvent.getParameter("arguments").rackid;
                let oRackDetailsModel = this.getOwnerComponent().getModel("routeModel");
                
                if(Object.keys(oRackDetailsModel.getData()).length == 0){
                    BusyIndicator.hide()
                    oRouter.navTo("TargetMain");
                    return
                }
                // if(oRouter.getParameter()){

                // }
                //set layout 
                this.getView().getModel("layoutMod").setProperty("/layout","TwoColumnsMidExpanded");
                
                this.oSelectedObject = oRackDetailsModel.getData();
                let oHeaderModel = new JSONModel();
                this.getView().setModel(oHeaderModel, "oHeaderModel");
                oHeaderModel.setData(this.oSelectedObject)
                let oView = this.getView();
                let aSlotItems = [];
                // To Fetch Order Header
                aSlotItems = await this._fetchSlotItems(this.oSelectedObject)
                    .catch(function (oError) {
                        oView.setBusy(false);
                        MessageBox.error(`Unable to retrieve the Data. Please try again.`)
                    });
                let oSlotItems = new JSONModel();
                this.getView().setModel(oSlotItems, "oSlotModel");
                oSlotItems.setData(aSlotItems);
                if(aSlotItems.length > 0){
                    //add CSS class
                    var grid = this.getView().byId("gridList").getItems();
                    this.addCSSClass(grid);
                }
            },
            _fetchSlotItems: function (HeaderData) {
                var that = this;
                let oDataModel = this.getOwnerComponent().getModel("mainServiceV2");
                var url = "/racks(guid'"+HeaderData.rack_id+"')/to_slots";
                return new Promise(function (resolve, reject) {
                    oDataModel.read(url, {
                        success: function (response) {
                            resolve(response['results']);
                        },
                        error: function (oError) {
                            reject(oError);
                        },
                    });
                });
    
            },
            handleItemPress: function (oEvent) {
                var oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(2),
                    supplierPath = oEvent.getSource().getSelectedItem().getBindingContext("products").getPath(),
                    supplier = supplierPath.split("/").slice(-1).pop();
    
                this.oRouter.navTo("detailDetail", {layout: oNextUIState.layout,
                    product: this._product, supplier: supplier});
            },
            handleFullScreen: function () {
                this.bFocusFullScreenButton = true;
                var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/fullScreen");
                this.oRouter.navTo("detail", {layout: sNextLayout, product: this._product});
            },
            handleExitFullScreen: function () {
                this.bFocusFullScreenButton = true;
                var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/exitFullScreen");
                this.oRouter.navTo("detail", {layout: sNextLayout, product: this._product});
            },
            handleClose: function () {
                var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/closeColumn");
                this.oRouter.navTo("list", {layout: sNextLayout});
            },
            onPress_Slot:function(oEvent){
                const oSelectedItem = oEvent.getSource();
                var that = this;
                // Get the binding context of the selected item
                const oContext = oSelectedItem.getBindingContext("oSlotModel").getObject();
                var InventoryFilter = [];
                InventoryFilter.push(new Filter("slot_id", FilterOperator.EQ, oContext['slot_id']));
				var oView = this.getView();

			if (!this._pDialog) {
				this._pDialog = Fragment.load({
					id: oView.getId(),
					name: "comtemlaapplication.fragment.Inventory",
					controller: this
				}).then(function (oDialog){
					return oDialog;
				});
			}

			this._pDialog.then(async function(oDialog){
                that.oInventoryDialog = oDialog;
                var aInventory = await that._fetchInventoryList(InventoryFilter);
                let oInventoryModel = new JSONModel(aInventory);
                that.oInventoryDialog.setModel(oInventoryModel, "oInventoryModel");
				that.oInventoryDialog.open();
			}.bind(this));
            },
            onCloseInventoryDialog:function(oEvent){
                this.oInventoryDialog.close();
            },
            _fetchInventoryList: function (oFilter) {
                let oDataModel = this.getOwnerComponent().getModel("mainServiceV2");
                var url = "/inventory";
                return new Promise(function (resolve, reject) {
                    oDataModel.read(url, {
                        filters: oFilter,
                        success: function (response) {
                            resolve(response['results']);
                        },
                        error: function (oError) {
                            reject(oError);
                        },
                    });
                });
            },
            onSelectInventory:function(oEvent){
                const oSelectedItem = oEvent.getSource();
                var that = this;
                // Get the binding context of the selected item
                const oContext = oSelectedItem.getBindingContext("oInventoryModel").getObject();
                //set Model for Component
                let oSelectedInventoryModel =
                    this.getOwnerComponent().getModel("oSelectedInventoryModel");
                oSelectedInventoryModel.setData(oContext);
                /////
                const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this.getView().getModel("layoutMod").setProperty("/layout","EndColumnFullScreen");
                oRouter.navTo("TargetMaterial", {
                    LT_ID: oContext["LT_ID"]
                });
                this.oInventoryDialog.close();
            },
            addCSSClass:function(items){
                items.forEach(element => {
                    //read status
                    if(element.getBindingContext("oSlotModel").getObject()["status"] == '1'){
                        element.removeStyleClass('InventoryBlank');
                        element.addStyleClass('InventoryFilled');
                    }else{
                        element.removeStyleClass('InventoryFilled');
                        element.addStyleClass('InventoryBlank');
                    }
                    
                    
                });
            }
    });
});