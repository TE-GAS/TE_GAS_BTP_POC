sap.ui.define([
    "sap/ui/core/mvc/Controller"
  ], (BaseController) => {
    "use strict";
  
    return BaseController.extend("comtemlaapplication.controller.Order", {
        onInit() {
        },
        onPressOrder:function(oEvent){
            const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            this.getView().getModel("layoutMod").setProperty("/layout","TwoColumnsMidExpanded");
            oRouter.navTo("TargetOrderDetail", {
                LT_ID: "ABA"
            });
        }
    });
  });