sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/BusyDialog",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
],
    function (
        Controller,
        Fragment,
        JSONModel,
        MessageToast,
        BusyDialog,
        Filter,
        FilterOperator,
        MessageBox
    ) {
        "use strict";

        return Controller.extend("comtemlaapplication.controller.Main", {
            onInit: async function () {
                let oRackModel = new JSONModel();
                this.getView().setModel(oRackModel, "oRackModel");
                let oRouteModel = new JSONModel();
                this.getOwnerComponent().setModel(oRouteModel, "routeModel");
                let oView = this.getView();
                //oView.setModel(this.getOwnerComponent().getModel("mainServiceV2"),"oFilterModel")
                let aRackDetails = [];
                // To Fetch Order Header
                aRackDetails = await this._fetchRackHeader()
                    .catch(function (oError) {
                        oView.setBusy(false);
                        MessageBox.error(`Unable to retrieve the Data. Please try again.`)
                    });
                aRackDetails = aRackDetails.results;
                oRackModel.setData(aRackDetails);
                oRackModel.refresh(true);
                this.getOwnerComponent().setModel(oRackModel, "oRackModel");
                //Initiate Route event here
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("TargetMain").attachPatternMatched(this._onObjectMatchedForRouteMain, this);
            },

            _onObjectMatchedForRouteMain: function () {
                //check filter status and apply
                //this.onSearch(this);        
            },
            _fetchRackHeader: function (oFilter) {
                var that = this;
                let oDataModel = this.getOwnerComponent().getModel("mainServiceV2");
                return new Promise(function (resolve, reject) {
                    oDataModel.read("/racks", {
                        filter: [oFilter],
                        success: function (response) {
                            resolve(response);
                        },
                        error: function (oError) {
                            reject(oError);
                        },
                    });
                });

            },
            onPressRow: function (oEvent) {
                let oRackDetailsModel =
                    this.getOwnerComponent().getModel("routeModel");
                // Get the selected item (row)        
                const oSelectedItem = oEvent.getSource();
                // Get the binding context of the selected item
                const oContext = oSelectedItem.getBindingContext("oRackModel");
                // Get the object bound to the selected item
                this.oSelectedObject = oContext.getObject();
                oRackDetailsModel.setData(this.oSelectedObject);
                const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                //set layout 
                this.getView().getModel("layoutMod").setProperty("/layout","TwoColumnsMidExpanded");
                //this.getView().getModel("layoutMod").setProperty("/layout","ThreeColumnsMidExpanded");
                oRouter.navTo("TargetDetail", {
                    rackid: this.oSelectedObject.rack_id
                });

            },
            onSearch: function (oEvent) {
                //final filter
                //collect all filter here
                var finalFilter = []

                //read warehouse filter
                var aWarehouse = [];
                var oWarehouse = [];
                if (this.getView().byId("WarehouseNumber").getSelectedItems().length) {
                    this.getView().byId("WarehouseNumber").getSelectedItems().forEach(function (oItem, index) {
                        aWarehouse.push(
                            new Filter("LGNUM", FilterOperator.EQ, oItem.getKey())
                        );
                    });
                    oWarehouse = new Filter({
                        filters: aWarehouse,
                        or: true
                    });
                    finalFilter.push(oWarehouse);
                }

                //read order filter
                var aOrder = [];
                var oOrder = [];
                if (this.getView().byId("OrderNumber").getSelectedItems().length) {
                    this.getView().byId("OrderNumber").getSelectedItems().forEach(function (oItem, index) {
                        aOrder.push(
                            new Filter("TANUM", FilterOperator.EQ, oItem.getKey())
                        );
                    });
                    oOrder = new Filter({
                        filters: aOrder,
                        or: true
                    });
                    finalFilter.push(oOrder);
                }

                var oFilters = new Array(new Filter({
                    filters: finalFilter,
                    and: true
                }));
                //update table with filter value
                this.getView().byId("idRouteTable").getBinding("items").filter(oFilters);
            }
        });
    });