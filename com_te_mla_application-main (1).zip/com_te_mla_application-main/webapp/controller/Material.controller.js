sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/m/HBox",
  "sap/m/Text",
  "sap/ui/model/json/JSONModel",
  "sap/ui/core/BusyIndicator",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/m/MessageBox",
  "sap/ui/export/library",
  "sap/ui/export/Spreadsheet",
  "sap/ui/core/Fragment"
  ], (Controller, HBox, Text, JSONModel, BusyIndicator, Filter, FilterOperator, MessageBox, ExportLibrary, Spreadsheet,Fragment) => {
    "use strict";
  
    return Controller.extend("comtemlaapplication.controller.Material", {
      onInit() {
        var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            oRouter.getRoute("TargetMaterial").attachPatternMatched(this._onObjectMatchedForDetails, this);
            //console.log("ReachedHere");
            let oMaterialHeaderModel = new JSONModel();
            this.getView().setModel(oMaterialHeaderModel, "oMaterialHeaderModel");

            //
            let oOrderItems = new JSONModel();
            this.getView().setModel(oOrderItems, "oOrderModel");
    },
        _onObjectMatchedForDetails: async function (oEvent) {
            var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            let oOrderModel = new JSONModel();
            this.getOwnerComponent().setModel(oOrderModel, "oOrderModel");
            var lt_id = oEvent.getParameter("arguments").LT_ID;
            let oInventoryModel = this.getOwnerComponent().getModel("oSelectedInventoryModel");
            
            if(Object.keys(oInventoryModel.getData()).length == 0){
                BusyIndicator.hide()
                oRouter.navTo("TargetDetail");
                return
            }
            this.oSelectedObject = oInventoryModel.getData();
            
            let oView = this.getView();
            let aMaterialDetail = [];
            let aOrderItems = [];
            //To fetch Material Details
            var ProductFilter = [];
            ProductFilter.push(new Filter("LT_ID", FilterOperator.EQ, this.oSelectedObject['LT_ID']));

            aMaterialDetail = await this._fetchaMaterialDetail(ProductFilter)
                .catch(function (oError) {
                    oView.setBusy(false);
                    MessageBox.error(`Unable to retrieve the Data. Please try again.`)
                });

            this.getView().getModel("oMaterialHeaderModel").setData(aMaterialDetail[0]);
            // To Fetch Order Header
            aOrderItems = await this._fetchOrderItems(ProductFilter)
                .catch(function (oError) {
                    oView.setBusy(false);
                    MessageBox.error(`Unable to retrieve the Data. Please try again.`)
                });

            this.getView().getModel("oOrderModel").setData(aOrderItems);
        },
        _fetchaMaterialDetail: function (oFilter) {
          let oDataModel = this.getOwnerComponent().getModel("mainServiceV2");
          var url = "/products";
          return new Promise(function (resolve, reject) {
              oDataModel.read(url, {
                  filters: oFilter,
                  success: function (response) {
                      resolve(response['results']);
                  },
                  error: function (oError) {
                      reject(oError);
                  },
              });
          });
      },
        _fetchOrderItems: function (oFilter) {
                let oDataModel = this.getOwnerComponent().getModel("mainServiceV2");
                var url = "/orders";
                return new Promise(function (resolve, reject) {
                    oDataModel.read(url, {
                        filters: oFilter,
                        success: function (response) {
                            resolve(response['results']);
                        },
                        error: function (oError) {
                            reject(oError);
                        },
                    });
                });
            },
        onPressOrder:async function(oEvent){
            var aOrderDetail = [];
            var oView = this.getView();
            // Get the selected item (row)        
            const oSelectedItem = oEvent.getSource();
            // Get the binding context of the selected item
            const oContext = oSelectedItem.getBindingContext("oOrderModel");
            // Get the object bound to the selected item
            this.oSelectedObject = oContext.getObject();
            // To Fetch Order Header
            var OrderDetailFilter = [];
            OrderDetailFilter.push(new Filter("order_id", FilterOperator.EQ, this.oSelectedObject['order_id']));

            aOrderDetail = await this._fetchOrderDetail(aOrderDetail)
            .catch(function (oError) {
                oView.setBusy(false);
                MessageBox.error(`Unable to retrieve the Data. Please try again.`)
            });
            let oOrderDetail = new JSONModel();
           // this.getView().setModel(oOrderDetail, "oOrderDetail");
            oOrderDetail.setData(aOrderDetail);


            var that = this;
            if (!this._pDialog) {
				this._pDialog = Fragment.load({
					//id: oView.getId(),
					name: "comtemlaapplication.fragment.OrderDetail",
					controller: this
				}).then(function (oDialog){
					return oDialog;
				});
			}

			this._pDialog.then(async function(oDialog){
                that.oOrderDetailDialog = oDialog;
                // var aInventory = await that._fetchInventoryList(InventoryFilter);
                // let oInventoryModel = new JSONModel(aInventory);
                that.oOrderDetailDialog.setModel(oOrderDetail, "oOrderDetail");
				that.oOrderDetailDialog.open();
			}.bind(this));
            },
        _fetchOrderDetail: function (oFilter) {
            var that = this;
            let oDataModel = this.getOwnerComponent().getModel("mainServiceV2");
            var url = "/order_details";
            return new Promise(function (resolve, reject) {
                oDataModel.read(url, {
                    filters: oFilter,
                    success: function (response) {
                        resolve(response['results'][0]);
                    },
                    error: function (oError) {
                        reject(oError);
                    },
                });
            });
    
        },
            onCloseOrderDetailDialog:function(){
                this.oOrderDetailDialog.close();
            }
    });
  });