sap.ui.define([
    "sap/ui/core/UIComponent",
    "comtemlaapplication/model/models",
    "sap/ui/model/json/JSONModel"
], (UIComponent, models,JSONModel) => {
    "use strict";

    return UIComponent.extend("comtemlaapplication.Component", {
        metadata: {
            manifest: "json",
            interfaces: [
                "sap.ui.core.IAsyncContentCreation"
            ]
        },

        init() {
            // var oModel = this.getModel("mainServiceV2");
            // oModel.setUseBatch(false);
            // call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);

            // set the device model
            this.setModel(models.createDeviceModel(), "device");

            //set layout data
            this.setModel(new JSONModel({layout:"OneColumn"}), "layoutMod");

            // enable routing
            this.getRouter().initialize();
        }
    });
});