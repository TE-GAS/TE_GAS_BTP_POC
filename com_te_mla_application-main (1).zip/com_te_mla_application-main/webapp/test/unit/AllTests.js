sap.ui.define([
	"com_te_mla_application/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
