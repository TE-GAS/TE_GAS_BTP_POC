/* global QUnit */

sap.ui.require(["comtemlaapplication/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
