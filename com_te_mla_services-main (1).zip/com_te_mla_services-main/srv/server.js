
import cds from "@sap/cds";
import bodyParser from 'body-parser';
import xlsx from 'xlsx';
import fileupload from 'express-fileupload';
import { getDbClient } from "./utils/persistance.js";
//const cds = require('@sap/cds');
import { v4 as uuid } from 'uuid';


cds.on("bootstrap", app => {
    app.use(fileupload({ createParentPath: true }));
    //upload excel Order List
    app.post('/odata/v4/mla-action/PostBulkOrder', bodyParser.json(), bodyParser.urlencoded({ extended: true }), async (req, res) => {
        //convert excel/xls to Array
        const workbook = xlsx.read(req.files.userlist.data, { type: 'buffer' });
        const workSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[workSheetName];
        const data = xlsx.utils.sheet_to_json(worksheet, { defval: '' });


        var output = await update_order_list(req, data);
        res.send(output)

    });

});

const update_order_list = async function (req, data) {
    //const srv = await cds.connect.to("mlaAction"); // Connect to the service
    const db = await getDbClient();
    let final_output = [];
    let imp_data = data;
    const { racks } = cds.entities("te.mla.master");
    const { inventory, products, orders ,slots} = cds.entities("te.mla.master");
    for(let i = 0; i <= data.length ; i++){
        let output = {};

        try {
            let data = imp_data[i];
            
            //validate Data
            
            const rack = await SELECT.from(racks).where`rack_id=${data.rack_id}`;
            if (rack.length == 0) {
                output["message"] = "Invalid Rack."
            }
            output["rack_id"] = data.rack_id;
    
            // //pick random slots
            // const slot_number = await db.run(SELECT.from("SLOTS").where({ RACK_ID: data.Rack, INVENTORY_COUNT: { '!=': 3 } }));
    
            // const { slots } = cds.entities("te.mla.master");
            // const slot = await SELECT.from(slots).where`rack_id=${data.Rack}`;
            // const selected_slot = slot_number[Math.floor(Math.random() * slot_number.length)];
    
             //create slot
             const slot_id = uuid()
            var slot_data = [{
                "slot_id": slot_id,
                "rack_id": data.rack_id,
                "slot_number": data.slot_number,
                "sequence": i+1,
                "status": "1"
            }];
    
            output["to_slot"] = slot_data;
    
    
            //create product
            const product_id = data.LT_ID;
            var product_data = [{
                "LT_ID": product_id,
                "material_id": data.material_id,
                "category": "medicine",
                "quantity_UOM": "KG"
            }];
    
            output["to_product"] = product_data;
            //create Inventry
            const inventory_id = uuid()
            var inventory_data = [{
                "inventory_id": inventory_id,
                "slot_id": slot_id,
                "LT_ID": product_id,
                "product_quantity": data.product_quantity
            }];
            output["to_inventory"] = inventory_data;
            //create order
            const order_id = uuid();
            var order_data = [{
                "order_id": order_id,
                "order_status": 1,
                "order_type": 1,
                "LT_ID": product_id
            }];
            output["to_orders"] = order_data;
    
            
            //update slots
            await INSERT(slot_data).into(slots);
            //post in order
            await INSERT(order_data).into(orders);
            //post in product
            await INSERT(product_data).into(products);
            //post inventory in slot
            await INSERT(inventory_data).into(inventory);
        } catch (error) {
            console.log(error.originalMessage);
            output["message"] = error.message
        }
        final_output.push(output);
    };
    return final_output;

}