import RestService from "../utils/restService.js";
class AdminRest extends RestService {
  async init() {
    return super.init("actions", import.meta.url);
  }
}

export default AdminRest;
