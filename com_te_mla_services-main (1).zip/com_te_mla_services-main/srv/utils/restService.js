import { post_order } from "../mla_actions_implementation/post_order.js";
import { get_order } from "../mla_actions_implementation/get_order.js";
import { get_product } from "../mla_actions_implementation/get_product.js";
import cds from "@sap/cds";
class RestService extends cds.ApplicationService {
  async init() {
    this.on("post_order", post_order );
    this.on("get_order", get_order );
    this.on("get_product", get_product );
  }
}

export { RestService as default };