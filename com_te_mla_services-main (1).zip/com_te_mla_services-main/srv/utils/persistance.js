
import cds from "@sap/cds"

/**
 * @type {import('@sap/cds').Service|undefined}
 */
let dbClient;

/**
 * 
 */
async function initClient() {
    dbClient = await cds.connect.to('db')
}

/**
 * Returns database client instance
 * @returns {Promise<import('@sap/cds').Service>}
 */
async function getDbClient() {
    if (!dbClient) await initClient();
    return dbClient;
}


export { getDbClient }