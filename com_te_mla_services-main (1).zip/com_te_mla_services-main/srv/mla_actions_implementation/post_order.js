import { getDbClient } from "../utils/persistance.js";
import cds from '@sap/cds';
//const cds = require('@sap/cds');
import { v4 as uuid } from 'uuid';

async function action(request) {
	const db = await getDbClient();
	let output = {};
	try {
		let data = request.data.odata;
		
		//validate Data
		const { racks } = cds.entities("te.mla.master");
		const rack = await SELECT.from(racks).where`rack_id=${data.rack_id}`;
		if (rack.length == 0) {
			output["message"] = "Invalid Rack."
		}
		output["rack_id"] = data.rack_id;

		//pick random slots
		const db = cds.tx(request);
		const slot_number = await db.run(SELECT.from("SLOTS").where({ RACK_ID: data.rack_id, INVENTORY_COUNT: { '!=': 3 } }));

		const { slots } = cds.entities("te.mla.master");
		const slot = await SELECT.from(slots).where`rack_id=${data.rack_id}`;
		const selected_slot = slot_number[Math.floor(Math.random() * slot_number.length)];

		//update slots
		var slot_data = [{
			"slot_id": selected_slot["SLOT_ID"],
			"rack_id": data.rack_id,
			"slot_number": selected_slot["SLOT_NUMBER"],
			"status": "1"
		}];

		output["to_slot"] = slot_data;


		//create product
		const product_id = data.LT_ID;
		var product_data = [{
			"LT_ID": product_id,
			"material_id": data.material_id,
			"category": data.category || null,
			"weight": data.weight || null,
			"wgt_UOM": data.wgt_UOM || null,
			"batch": data.batch || null,
			"exp_date": data.exp_date || null,
			"dimension": data.dimension || null,
			"dim_uom": data.dim_uom || null,
			"quantity_UOM": data.quantity_UOM || null
		}];

		output["to_product"] = product_data;
		//create Inventry
		const inventory_id = uuid()
		var inventory_data = [{
			"inventory_id": inventory_id,
			"slot_id": selected_slot["SLOT_ID"],
			"LT_ID": product_id,
			"product_quantity": data.product_quantity
		}];
		output["to_inventory"] = inventory_data;
		//create order
		const order_id = uuid();
		var order_data = [{
			"order_id": order_id,
			"order_status": 1,
			"order_type": 1,
			"LT_ID": product_id
		}];
		output["to_orders"] = order_data;

		const { inventory, products, orders } = cds.entities("te.mla.master");
		//update slots
		await UPSERT(slot_data).into(slots)
		//post in order
		await INSERT(order_data).into(orders);
		//post in product
		await INSERT(product_data).into(products);
		//post inventory in slot
		await INSERT(inventory_data).into(inventory);

	} catch (error) {
		console.log(error.originalMessage);
		output = {}
		output["message"] = error.originalMessage || error.message 
	}
	return output;

}

export { action as post_order };
