import { getDbClient } from "../utils/persistance.js";
import cds from '@sap/cds';
//const cds = require('@sap/cds');
import { v4 as uuid } from 'uuid';

async function action(request) {
	try {
		let data = request.data.odata;
		let output = {};
		//validate Data


		//pick random slots
		const db = cds.tx(request);
		const inventory_number = await db.run(SELECT.from("PRODUCT_AVAILABILITY").where({
			 MATERIAL_ID: data.material_id, PRODUCT_QUANTITY: { ">=": data.product_quantity }
		}));
		if (inventory_number.length == 0) {
			output["message"] = `Product Quantity ${data.product_quantity} is not available.`
			return output
		}
		//select random inventory
		const selected_inventory = inventory_number[Math.floor(Math.random() * inventory_number.length)];
		const { inventory, orders, slots, products } = cds.entities("te.mla.master");
		//get Inventory detail
		const inventory_detail = await SELECT.from(inventory, { inventory_id: selected_inventory["INVENTORY_ID"] })
		// calulate product count
		if (parseInt(inventory_detail["product_quantity"]) == parseInt(data.product_quantity)) {
			//delete Inventory
			await DELETE.from(inventory).where({ inventory_id: inventory_detail['inventory_id'] })
			//delete from product table 
			await DELETE.from(products).where({ LT_ID: selected_inventory["LT_ID"], material_id: selected_inventory["MATERIAL_ID"] })
			//check slots and clear status
		} else {
			//update invetory
			const quantity = parseInt(inventory_detail['product_quantity']) - parseInt(data.product_quantity)
			await UPDATE(inventory).set({ product_quantity: quantity }).where({ inventory_id: inventory_detail['inventory_id'] });
			//append product detail

			//get product
			const product_detail = await SELECT.from(products, { LT_ID: selected_inventory["LT_ID"] })

			var product_data = [{
				"LT_ID": product_detail["LT_ID"],
				"material_id": product_detail["material_id"],
				"category": product_detail["category"],
				"quantity_UOM": product_detail["quantity_UOM"]
			}];

			output["to_product"] = product_data;

			//get Inventry
			const inventory_details = await SELECT.from(inventory, { inventory_id: selected_inventory["INVENTORY_ID"] })
			var inventory_data = [{
				"inventory_id": inventory_details["inventory_id"],
				"slot_id": inventory_details["slot_id"],
				"LT_ID": inventory_details["LT_ID"],
				"product_retrive_quantity": data.product_quantity ,
				"product_remain_quantity": inventory_details["product_quantity"]
			}];
			output["to_inventory"] = inventory_data;
		}



		//create reponse
		//get slots
		const slot_detail = await SELECT.from(slots, { slot_id: selected_inventory["SLOT_ID"] })
		var slot_data = [{
			"slot_id": slot_detail["slot_id"],
			"rack_id": slot_detail['rack_id'],
			"slot_number": slot_detail["slot_number"],
			"status": slot_detail['status']
		}];

		output["to_slot"] = slot_data;


		//create order
		const order_id = uuid();
		var order_data = [{
			"order_id": order_id,
			"order_status": 1,
			"order_type": data.order_type,
			"LT_ID":  selected_inventory["LT_ID"]
		}];
		output["to_orders"] = order_data;
		output["message"] = "Order Successfull!";

		//post in order
		await INSERT(order_data).into(orders);


		return output;
	} catch (error) {
		console.log(error.originalMessage);
		return "Error while posting Order!!"
	}

}

export { action as get_order };
