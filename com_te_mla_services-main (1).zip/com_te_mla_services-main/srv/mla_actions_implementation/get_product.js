import { getDbClient } from "../utils/persistance.js";
import cds from '@sap/cds';
//const cds = require('@sap/cds');
import { v4 as uuid } from 'uuid';

async function action(request) {
    try {
        let data = request.data.odata;
        let output = {};
        let final_output = [{"product_detail":[]}];
        let material_info = []
        //validate Data
        const { inventory, orders, slots, products } = cds.entities("te.mla.master");
        //const product_detail = await SELECT.from(products, { material_id: data.material_id });
        const product_detail = await cds.run( SELECT.from(products). where({ material_id: data.material_id }));
        // if(typeof(product_detail) == 'object'){
        //     let array = [];
        //     array.push(product_detail)
        //     material_info = [...array]
        // }else{
        //     material_info = [...product_detail]
        // }
        if (product_detail.length == 0) {
            output["message"] = `Invalid Product.`
            return output
        }
        for (let i = 0; i < product_detail.length; i++) {
            //product detail
            var product_data = [{
                "LT_ID": product_detail[i]["LT_ID"],
                "material_id": product_detail[i]["material_id"],
                "category": product_detail[i]["category"],
                "quantity_UOM": product_detail[i]["quantity_UOM"]
            }];

            output["to_product"] = product_data;

            //get Inventry
            const inventory_details = await SELECT.from(inventory, { LT_ID: product_detail[i]["LT_ID"] });
            var inventory_data = [{
                "inventory_id": inventory_details["inventory_id"],
                "slot_id": inventory_details["slot_id"],
                "LT_ID": inventory_details["LT_ID"],
                "product_quantity": inventory_details["product_quantity"]
            }];
            output["to_inventory"] = inventory_data;

            //get slots
            const slot_detail = await SELECT.from(slots, { slot_id: inventory_details["slot_id"] })
            var slot_data = [{
                "slot_id": slot_detail["slot_id"],
                "rack_id": slot_detail['rack_id'],
                "slot_number": slot_detail["slot_number"],
                "status": slot_detail['status']
            }];

            output["to_slot"] = slot_data;

            //read order
            const order_detail = await SELECT.from(orders, { LT_ID: product_detail[i]["LT_ID"] })
            var order_data = [{
                "order_id": order_detail["order_id"],
                "order_status": order_detail["order_status"],
                "order_type": order_detail["order_type"],
                "LT_ID": order_detail["LT_ID"]
            }];
            output["to_orders"] = order_data;
            output["message"] = "Reading Product Detail Successfull!";
            final_output[0]["product_detail"].push(output);
        }


        return final_output;
    } catch (error) {
        output["message"] = error.message || error.originalMessage;
        final_output[0]["product_detail"].push(output);
        return final_output;
    }

}

export { action as get_product };
