import cds from '@sap/cds';

export default async function (srv){

    srv.on("READ", "slots_status", async (req) => {
        const db = cds.tx(req);
        const data = await db.run(SELECT.from("SLOTS"));
        return data;
    });  

    srv.on("READ", "slots", async (req) => {
        const db = cds.tx(req);
            const { slots } = cds.entities("te.mla.master");
            const data = await db.run(SELECT.from(slots));
            if(data.length > 0){
                for(let i = 0 ; i < data.length ; i++){
                    const slot_data = await db.run(SELECT.from("SLOTS").where({ SLOT_ID: data[i].slot_id }));
                    if(slot_data.length > 0){
                        data[i]["inventory_count"] = slot_data[0]["INVENTORY_COUNT"]
                    }else{
                        data["inventory_count"] = 0;
                    }
                    
                }          
            }
            return data;
        }
    );
}
